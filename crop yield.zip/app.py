from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

app = Flask(__name__)

# Load dataset
data = pd.read_csv('crop_data.csv')

# Train model
X = data[['rainfall', 'temperature', 'area']]
y = data['yield']

model = RandomForestRegressor()
model.fit(X, y)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    rainfall = float(request.form['rainfall'])
    temperature = float(request.form['temperature'])
    area = float(request.form['area'])

    prediction = model.predict([[rainfall, temperature, area]])

    return render_template('index.html', prediction_text=f'Predicted Yield: {prediction[0]:.2f}')

if __name__ == '__main__':
    app.run(debug=True)
